# Shri Airavat Food's — Android app

This package is the Firebase-connected native Android build project.

- Firebase package: `com.shri.airawatfoods`
- Admin entry: long-press the top title `श्री ऐरावत Food's`
- Firebase config is included at `app/google-services.json`.
