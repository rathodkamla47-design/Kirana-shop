package com.shri.airawatfoods;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;
import java.util.*;

public class MainActivity extends AppCompatActivity {
  final int MAROON=Color.rgb(92,22,32), GOLD=Color.rgb(176,126,45), CREAM=Color.rgb(250,244,229);
  LinearLayout root; FirebaseFirestore db; FirebaseAuth auth;
  ArrayList<Map<String,Object>> products=new ArrayList<>();
  ArrayList<Map<String,Object>> cart=new ArrayList<>();
  TextView title; Button cartButton;

  @Override public void onCreate(Bundle b){super.onCreate(b);db=FirebaseFirestore.getInstance();auth=FirebaseAuth.getInstance();splash();}
  TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(MAROON);t.setPadding(20,14,20,14);return t;}
  Button btn(String s){Button b=new Button(this);b.setText(s);return b;}
  EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(16);e.setPadding(20,12,20,12);return e;}

  void base(){
    root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(CREAM);setContentView(root);
    LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setBackgroundColor(MAROON);
    title=tv("श्री ऐरावत Food's",20);title.setTextColor(Color.WHITE);bar.addView(title,new LinearLayout.LayoutParams(0,-2,1));
    cartButton=btn("Cart ("+cartCount()+")");cartButton.setOnClickListener(v->cartScreen());bar.addView(cartButton,new LinearLayout.LayoutParams(-2,-2));
    title.setOnLongClickListener(v->{adminLogin();return true;});root.addView(bar);
  }
  void splash(){ImageView im=new ImageView(this);im.setImageResource(com.shri.airawatfoods.R.drawable.airavat_splash);im.setScaleType(ImageView.ScaleType.CENTER_CROP);setContentView(im);im.setOnClickListener(v->home());new Handler().postDelayed(this::home,1800);}
  void home(){base();root.addView(tv("श्री ऐरावत Food's",28));Button order=btn("Order Now");root.addView(order);order.setOnClickListener(v->loadProducts());}

  void loadProducts(){
    base();root.addView(tv("Products",22));ProgressBar p=new ProgressBar(this);root.addView(p);
    db.collection("products").whereEqualTo("active",true).orderBy("sortOrder",Query.Direction.ASCENDING).get()
      .addOnSuccessListener(q->{p.setVisibility(View.GONE);products.clear();for(DocumentSnapshot d:q){Map<String,Object> m=new HashMap<>(d.getData());m.put("id",d.getId());products.add(m);}productList();})
      .addOnFailureListener(e->{p.setVisibility(View.GONE);root.addView(tv("Products load नहीं हुए.\n"+e.getMessage(),15));});
  }

  void productList(){
    base();root.addView(tv("Products",22));
    for(Map<String,Object> m:products){
      LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(12,6,12,6);
      String n=String.valueOf(m.get("name"));Object wObj=m.get("weight");if(wObj==null)wObj=m.get("waight");String w=wObj==null?"":String.valueOf(wObj).trim();if("null".equalsIgnoreCase(w))w="";
      String pr=String.valueOf(m.get("price"));String displayStock=String.valueOf(m.get("stock") == null ? "Available" : m.get("stock"));c.addView(tv(n+"\n"+w+"   ₹"+pr+"   Stock: "+displayStock,18));
      LinearLayout qrow=new LinearLayout(this);qrow.setGravity(Gravity.CENTER_VERTICAL);
      Button minus=btn("−");TextView qtv=tv(String.valueOf(currentQty(m)),18);Button plus=btn("+");Button add=btn("Add to Cart");Object so=m.get("stock");int stock=999999;try{stock=Integer.parseInt(String.valueOf(so));}catch(Exception e){}if(stock<=0){add.setEnabled(false);add.setText("Out of Stock");plus.setEnabled(false);}
      qrow.addView(minus);qrow.addView(qtv,new LinearLayout.LayoutParams(0,-2,1));qrow.addView(plus);qrow.addView(add);c.addView(qrow);
      minus.setOnClickListener(v->{int q=currentQty(m);if(q>0){setQty(m,q-1);qtv.setText(String.valueOf(currentQty(m)));refreshCartButton();}});
      plus.setOnClickListener(v->{addToCart(m,1);qtv.setText(String.valueOf(currentQty(m)));refreshCartButton();});
      add.setOnClickListener(v->{addToCart(m,1);qtv.setText(String.valueOf(currentQty(m)));refreshCartButton();Toast.makeText(this,"Cart में जोड़ा गया",Toast.LENGTH_SHORT).show();});
      root.addView(c);
    }
  }

  int currentQty(Map<String,Object> m){for(Map<String,Object> x:cart)if(String.valueOf(x.get("id")).equals(String.valueOf(m.get("id"))))return ((Number)x.getOrDefault("qty",1)).intValue();return 0;}
  int cartCount(){int n=0;for(Map<String,Object> x:cart)n+=((Number)x.getOrDefault("qty",1)).intValue();return n;}
  void setQty(Map<String,Object> m,int q){for(int i=0;i<cart.size();i++){Map<String,Object> x=cart.get(i);if(String.valueOf(x.get("id")).equals(String.valueOf(m.get("id")))){if(q<=0)cart.remove(i);else x.put("qty",q);return;}}}
  void addToCart(Map<String,Object> m,int q){for(Map<String,Object> x:cart)if(String.valueOf(x.get("id")).equals(String.valueOf(m.get("id")))){int old=((Number)x.getOrDefault("qty",1)).intValue();x.put("qty",old+q);return;}Map<String,Object> copy=new HashMap<>(m);copy.put("qty",q);cart.add(copy);}
  double price(Map<String,Object> m){Object p=m.get("price");try{return Double.parseDouble(String.valueOf(p));}catch(Exception e){return 0;}}
  double total(){double t=0;for(Map<String,Object> m:cart)t+=price(m)*((Number)m.getOrDefault("qty",1)).intValue();return t;}
  void refreshCartButton(){ if(cartButton!=null) cartButton.setText("Cart ("+cartCount()+")"); }

  void cartScreen(){
    base();root.addView(tv("Your Cart",22));
    if(cart.isEmpty()){root.addView(tv("Cart खाली है",18));Button b=btn("Continue Shopping");root.addView(b);b.setOnClickListener(v->loadProducts());return;}
    for(Map<String,Object> m:new ArrayList<>(cart)){
      LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(12,8,12,8);
      String n=String.valueOf(m.get("name"));Object wObj=m.get("weight");if(wObj==null)wObj=m.get("waight");String w=wObj==null?"":String.valueOf(wObj);int q=((Number)m.getOrDefault("qty",1)).intValue();
      row.addView(tv(n+"\n"+w+"   ₹"+price(m)+" x "+q,18));
      LinearLayout qrow=new LinearLayout(this);Button minus=btn("−");TextView qt=tv(String.valueOf(q),18);Button plus=btn("+");Button del=btn("Remove");qrow.addView(minus);qrow.addView(qt,new LinearLayout.LayoutParams(0,-2,1));qrow.addView(plus);qrow.addView(del);row.addView(qrow);root.addView(row);
      minus.setOnClickListener(v->{setQty(m,currentQty(m)-1);cartScreen();});plus.setOnClickListener(v->{addToCart(m,1);cartScreen();});del.setOnClickListener(v->{setQty(m,0);cartScreen();});
    }
    root.addView(tv("Total Amount: ₹"+money(total()),20));Button proceed=btn("Proceed to Order");root.addView(proceed);proceed.setOnClickListener(v->checkout());
  }
  String money(double n){if(n==Math.rint(n))return String.valueOf((long)n);return String.format(Locale.US,"%.2f",n);}

  void checkout(){
    base();root.addView(tv("Order Details",22));root.addView(tv("Customer Information",19));
    EditText name=input("Name");EditText mobile=input("Mobile Number");mobile.setInputType(2);EditText address=input("Address");address.setMinLines(3);address.setGravity(Gravity.TOP);root.addView(name);root.addView(mobile);root.addView(address);
    root.addView(tv("Order Total: ₹"+money(total()),19));Button place=btn("Place Order");root.addView(place);
    place.setOnClickListener(v->{String ns=name.getText().toString().trim(),ms=mobile.getText().toString().trim(),as=address.getText().toString().trim();if(ns.isEmpty()||ms.isEmpty()||as.isEmpty()){Toast.makeText(this,"Name, Mobile और Address भरें",Toast.LENGTH_SHORT).show();return;}placeOrder(ns,ms,as);});
  }

  void placeOrder(String name,String mobile,String address){
    ArrayList<Map<String,Object>> items=new ArrayList<>();for(Map<String,Object> m:cart){Map<String,Object> x=new HashMap<>();x.put("productId",m.get("id"));x.put("name",m.get("name"));x.put("weight",m.get("weight"));x.put("price",price(m));x.put("qty",m.get("qty"));x.put("lineTotal",price(m)*((Number)m.getOrDefault("qty",1)).intValue());items.add(x);}
    Map<String,Object> order=new HashMap<>();order.put("name",name);order.put("mobile",mobile);order.put("address",address);order.put("items",items);order.put("total",total());order.put("status","Accepted");order.put("createdAt",FieldValue.serverTimestamp());
    double orderTotal=total();
    db.collection("orders").add(order).addOnSuccessListener(r->{String id=r.getId();cart.clear();base();root.addView(tv("Order Placed Successfully",24));root.addView(tv("Order ID: "+id,17));root.addView(tv("Total: ₹"+money(orderTotal),19));root.addView(tv("Status: Accepted",18));}).addOnFailureListener(e->Toast.makeText(this,"Order save नहीं हुआ: "+e.getMessage(),Toast.LENGTH_LONG).show());
  }

  void adminLogin(){final EditText e=input("Admin Email");final EditText p=input("Password");p.setInputType(129);LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.addView(e);l.addView(p);new AlertDialog.Builder(this).setTitle("Admin Login").setView(l).setPositiveButton("Login",(d,w)->auth.signInWithEmailAndPassword(e.getText().toString().trim(),p.getText().toString()).addOnSuccessListener(x->admin()).addOnFailureListener(x->Toast.makeText(this,"Login failed",Toast.LENGTH_SHORT).show())).setNegativeButton("Cancel",null).show();}
  void admin(){base();root.addView(tv("Admin Panel",22));Button add=btn("Add / Edit Products");Button orders=btn("Customer Orders");root.addView(add);root.addView(orders);add.setOnClickListener(v->adminProducts());orders.setOnClickListener(v->adminOrders());}
  void adminProducts(){base();root.addView(tv("Products Management",22));Button add=btn("Add Product");root.addView(add);add.setOnClickListener(v->editProduct(null));db.collection("products").get().addOnSuccessListener(q->{for(DocumentSnapshot d:q){Button b=btn(d.getString("name")+"  ₹"+d.get("price"));root.addView(b);b.setOnClickListener(v->editProduct(d));}});}
  void editProduct(DocumentSnapshot d){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText n=input("Product name");EditText w=input("Weight");EditText p=input("Price");EditText s=input("Stock quantity");EditText a=input("Available: हाँ / नहीं");if(d!=null){n.setText(d.getString("name"));w.setText(d.getString("weight"));p.setText(String.valueOf(d.get("price")));a.setText(String.valueOf(d.get("available")));s.setText(String.valueOf(d.get("stock") == null ? "0" : d.get("stock")));}l.addView(n);l.addView(w);l.addView(p);l.addView(s);l.addView(a);new AlertDialog.Builder(this).setTitle(d==null?"Add Product":"Edit Product").setView(l).setPositiveButton("Save",(x,y)->{Map<String,Object> m=new HashMap<>();m.put("name",n.getText().toString());m.put("weight",w.getText().toString());m.put("price",p.getText().toString());m.put("stock",s.getText().toString());m.put("available",a.getText().toString());m.put("active",true);m.put("sortOrder",System.currentTimeMillis());if(d==null)db.collection("products").add(m);else d.getReference().update(m);Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show();}).setNegativeButton("Cancel",null).show();}
  void adminOrders(){base();root.addView(tv("Customer Orders",22));db.collection("orders").orderBy("createdAt",Query.Direction.DESCENDING).limit(50).get().addOnSuccessListener(q->{for(DocumentSnapshot d:q){String s="Order: "+d.getId()+"\nCustomer: "+d.getString("name")+"\nMobile: "+d.getString("mobile")+"\nTotal: ₹"+d.get("total")+"\nStatus: "+d.getString("status");TextView t=tv(s,16);root.addView(t);Button bill=btn("Send Bill on WhatsApp");root.addView(bill);bill.setOnClickListener(v->sendBill(d));Button st=btn("Update Status");root.addView(st);st.setOnClickListener(v->status(d));}});}

  void sendBill(DocumentSnapshot d){
    String mobile=d.getString("mobile");
    if(mobile==null||mobile.trim().isEmpty()){Toast.makeText(this,"Customer mobile नहीं मिला",Toast.LENGTH_SHORT).show();return;}
    mobile=mobile.replaceAll("\\D","");
    if(mobile.length()==10) mobile="91"+mobile;
    String msg="श्री ऐरावत Food's\nOrder ID: "+d.getId()+"\nCustomer: "+d.getString("name")+"\nTotal: ₹"+d.get("total")+"\nStatus: "+d.getString("status")+"\nधन्यवाद!";
    try{Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"+mobile+"?text="+Uri.encode(msg)));startActivity(i);}
    catch(Exception e){Toast.makeText(this,"WhatsApp नहीं खुला",Toast.LENGTH_SHORT).show();}
  }
  void status(DocumentSnapshot d){String[] ss={"Accepted","Processing","Out for Delivery","Delivered","Cancel"};new AlertDialog.Builder(this).setTitle("Order Status").setItems(ss,(x,i)->d.getReference().update("status",ss[i])).setNegativeButton("Cancel",null).show();}
  @Override public void onBackPressed(){home();}
}
