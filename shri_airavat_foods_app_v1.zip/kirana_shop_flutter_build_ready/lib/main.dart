import 'package:flutter/material.dart';

void main() => runApp(const AiravatApp());

class Product {
  String name;
  String weight;
  double price;
  bool available;
  String imageUrl;

  Product({
    required this.name,
    required this.weight,
    required this.price,
    this.available = true,
    this.imageUrl = '',
  });
}

final List<Product> products = [
  Product(name: 'राजगीरा आटा', weight: '500 ग्राम', price: 0, imageUrl: 'https://images.unsplash.com/photo-1628102491629-778571d893a3?w=500'),
  Product(name: 'सिंघाड़ा आटा', weight: '500 ग्राम', price: 0, imageUrl: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=500'),
  Product(name: 'मोरधन', weight: '500 ग्राम', price: 0, imageUrl: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=500'),
  Product(name: 'बेसन', weight: '500 ग्राम', price: 0, imageUrl: 'https://images.unsplash.com/photo-1612257416648-ee7a9b8f3a8d?w=500'),
  Product(name: 'रवा', weight: '500 ग्राम', price: 0, imageUrl: 'https://images.unsplash.com/photo-1601050690117-94f5f6fa8bd7?w=500'),
  Product(name: 'मैदा', weight: '500 ग्राम', price: 0, imageUrl: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=500'),
  Product(name: 'परमल', weight: '1 किलो', price: 0, imageUrl: 'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?w=500'),
  Product(name: 'पोहा', weight: '500 ग्राम', price: 0, imageUrl: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=500'),
  Product(name: 'काला नमक', weight: '500 ग्राम', price: 0),
  Product(name: 'सेंधा नमक', weight: '500 ग्राम', price: 0),
  Product(name: 'दूध मसाला', weight: '100 ग्राम', price: 0),
  Product(name: 'छाछ मसाला', weight: '100 ग्राम', price: 0),
];

class AiravatApp extends StatelessWidget {
  const AiravatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "श्री ऐरावत Food's",
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.orange,
        scaffoldBackgroundColor: const Color(0xFFFFFBF5),
      ),
      home: const CustomerHome(),
    );
  }
}

class CustomerHome extends StatefulWidget {
  const CustomerHome({super.key});
  @override State<CustomerHome> createState() => _CustomerHomeState();
}

class _CustomerHomeState extends State<CustomerHome> {
  final Map<Product, int> cart = {};
  int tab = 0;

  void add(Product p) {
    if (!p.available || p.price <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('इस product की कीमत अभी Admin ने तय नहीं की है।')),
      );
      return;
    }
    setState(() => cart[p] = (cart[p] ?? 0) + 1);
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _shop(),
      CartPage(cart: cart, onChanged: () => setState(() {})),
      const AdminLoginPage(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("श्री ऐरावत Food's", style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.receipt_long),
            tooltip: 'My Orders',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OrdersPage())),
          ),
        ],
      ),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.storefront), label: 'Products'),
          NavigationDestination(icon: Icon(Icons.shopping_cart), label: 'Cart'),
          NavigationDestination(icon: Icon(Icons.lock), label: 'Admin'),
        ],
      ),
    );
  }

  Widget _shop() {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  child: const Text('🐘', style: TextStyle(fontSize: 34)),
                ),
                const SizedBox(width: 14),
                const Expanded(
                  child: Text(
                    "श्री ऐरावत Food's\nQuality products • Easy ordering",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        ...products.map((p) => ProductCard(product: p, onAdd: () => add(p))),
      ],
    );
  }
}

class ProductCard extends StatelessWidget {
  final Product product;
  final VoidCallback onAdd;
  const ProductCard({super.key, required this.product, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Row(
          children: [
            Container(
              width: 82,
              height: 82,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: Colors.orange.shade50,
              ),
              clipBehavior: Clip.antiAlias,
              child: product.imageUrl.isEmpty
                  ? const Center(child: Text('🛍️', style: TextStyle(fontSize: 38)))
                  : Image.network(product.imageUrl, fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const Center(child: Text('🛍️', style: TextStyle(fontSize: 38)))),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(product.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 5),
                  Text('Weight: ${product.weight}'),
                  const SizedBox(height: 4),
                  Text(
                    product.price > 0 ? '₹${product.price.toStringAsFixed(2)}' : 'Price Admin तय करेगा',
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
                  ),
                  if (!product.available)
                    const Text('Out of stock', style: TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            FilledButton(
              onPressed: product.available && product.price > 0 ? onAdd : null,
              child: const Text('Add'),
            ),
          ],
        ),
      ),
    );
  }
}

class CartPage extends StatefulWidget {
  final Map<Product, int> cart;
  final VoidCallback onChanged;
  const CartPage({super.key, required this.cart, required this.onChanged});
  @override State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  double get total => widget.cart.entries.fold(0, (s, e) => s + e.key.price * e.value);

  @override
  Widget build(BuildContext context) {
    if (widget.cart.isEmpty) {
      return const Center(child: Text('Cart खाली है', style: TextStyle(fontSize: 20)));
    }
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(12),
            children: widget.cart.entries.map((e) {
              final p = e.key;
              final q = e.value;
              return Card(
                child: ListTile(
                  title: Text(p.name),
                  subtitle: Text('${p.weight} • ₹${p.price.toStringAsFixed(2)} × $q'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(onPressed: () => _change(p, -1), icon: const Icon(Icons.remove_circle_outline)),
                      Text('$q'),
                      IconButton(onPressed: () => _change(p, 1), icon: const Icon(Icons.add_circle_outline)),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        SafeArea(
          child: Card(
            margin: const EdgeInsets.all(12),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  Text('Total: ₹${total.toStringAsFixed(2)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => CheckoutPage(cart: widget.cart, total: total)),
                      ),
                      child: const Text('Order करें'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _change(Product p, int delta) {
    setState(() {
      final n = (widget.cart[p] ?? 0) + delta;
      if (n <= 0) {
        widget.cart.remove(p);
      } else {
        widget.cart[p] = n;
      }
    });
    widget.onChanged();
  }
}

class CheckoutPage extends StatefulWidget {
  final Map<Product, int> cart;
  final double total;
  const CheckoutPage({super.key, required this.cart, required this.total});
  @override State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  final name = TextEditingController();
  final phone = TextEditingController();
  final address = TextEditingController();
  final location = TextEditingController();

  @override
  void dispose() {
    name.dispose(); phone.dispose(); address.dispose(); location.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Order Details')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Customer Details', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Customer Name', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Mobile Number', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: address, maxLines: 2, decoration: const InputDecoration(labelText: 'Address', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: location, decoration: const InputDecoration(labelText: 'Location / Landmark', border: OutlineInputBorder())),
          const SizedBox(height: 18),
          Card(child: ListTile(title: const Text('Bill Total'), trailing: Text('₹${widget.total.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)))),
          const SizedBox(height: 18),
          FilledButton(
            onPressed: _placeOrder,
            child: const Text('Order Submit करें'),
          ),
        ],
      ),
    );
  }

  void _placeOrder() {
    if (name.text.trim().isEmpty || phone.text.trim().isEmpty || address.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Name, Mobile और Address भरना जरूरी है।')));
      return;
    }
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => BillPage(
          customerName: name.text.trim(),
          phone: phone.text.trim(),
          address: address.text.trim(),
          location: location.text.trim(),
          cart: widget.cart,
          total: widget.total,
        ),
      ),
    );
  }
}

class BillPage extends StatelessWidget {
  final String customerName, phone, address, location;
  final Map<Product, int> cart;
  final double total;

  const BillPage({
    super.key,
    required this.customerName,
    required this.phone,
    required this.address,
    required this.location,
    required this.cart,
    required this.total,
  });

  @override
  Widget build(BuildContext context) {
    final orderId = 'SAF-${DateTime.now().millisecondsSinceEpoch.toString().substring(6)}';
    return Scaffold(
      appBar: AppBar(title: const Text('Order Bill')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Center(child: Text("श्री ऐरावत Food's", style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold))),
          const SizedBox(height: 6),
          Center(child: Text('Order ID: $orderId')),
          const Divider(height: 28),
          Text('Customer: $customerName'),
          Text('Mobile: $phone'),
          Text('Address: $address'),
          if (location.isNotEmpty) Text('Location: $location'),
          const SizedBox(height: 12),
          ...cart.entries.map((e) => ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(e.key.name),
            subtitle: Text('${e.key.weight} × ${e.value}'),
            trailing: Text('₹${(e.key.price * e.value).toStringAsFixed(2)}'),
          )),
          const Divider(),
          Align(
            alignment: Alignment.centerRight,
            child: Text('Total: ₹${total.toStringAsFixed(2)}', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(height: 18),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(14),
              child: Text('Status: Order Received ✅', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }
}

class OrdersPage extends StatelessWidget {
  const OrdersPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Orders')),
      body: const Center(
        child: Text('आपके orders यहाँ दिखाई देंगे।', style: TextStyle(fontSize: 18)),
      ),
    );
  }
}

class AdminLoginPage extends StatefulWidget {
  const AdminLoginPage({super.key});
  @override State<AdminLoginPage> createState() => _AdminLoginPageState();
}

class _AdminLoginPageState extends State<AdminLoginPage> {
  final id = TextEditingController();
  final password = TextEditingController();
  bool hide = true;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: ListView(
        children: [
          const SizedBox(height: 30),
          const Icon(Icons.admin_panel_settings, size: 80),
          const SizedBox(height: 15),
          const Center(child: Text('Admin Login', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold))),
          const SizedBox(height: 25),
          TextField(controller: id, decoration: const InputDecoration(labelText: 'Login ID', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(
            controller: password,
            obscureText: hide,
            decoration: InputDecoration(
              labelText: 'Password',
              border: const OutlineInputBorder(),
              suffixIcon: IconButton(icon: Icon(hide ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => hide = !hide)),
            ),
          ),
          const SizedBox(height: 18),
          FilledButton(
            onPressed: () {
              if (id.text.trim() == 'admin' && password.text == '1234') {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPanel()));
              } else {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Login ID या Password गलत है।')));
              }
            },
            child: const Text('Login'),
          ),
          const SizedBox(height: 10),
          const Text('Demo login: admin / 1234', textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

class AdminPanel extends StatefulWidget {
  const AdminPanel({super.key});
  @override State<AdminPanel> createState() => _AdminPanelState();
}

class _AdminPanelState extends State<AdminPanel> {
  void editProduct(Product p) {
    final price = TextEditingController(text: p.price == 0 ? '' : p.price.toStringAsFixed(0));
    final weight = TextEditingController(text: p.weight);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(p.name),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: weight, decoration: const InputDecoration(labelText: 'Weight')),
            TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Price (₹)')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              setState(() {
                p.weight = weight.text.trim().isEmpty ? p.weight : weight.text.trim();
                p.price = double.tryParse(price.text.trim()) ?? p.price;
              });
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Admin Panel')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            child: const ListTile(
              leading: Icon(Icons.security),
              title: Text('Admin Control'),
              subtitle: Text('Product, weight, price और availability manage करें।'),
            ),
          ),
          ...products.map((p) => Card(
            child: ListTile(
              title: Text(p.name),
              subtitle: Text('${p.weight} • ${p.price > 0 ? '₹${p.price.toStringAsFixed(0)}' : 'Price not set'}'),
              trailing: IconButton(icon: const Icon(Icons.edit), onPressed: () => editProduct(p)),
            ),
          )),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: () => _addProduct(),
            icon: const Icon(Icons.add),
            label: const Text('Any Product जोड़ें'),
          ),
        ],
      ),
    );
  }

  void _addProduct() {
    final name = TextEditingController();
    final weight = TextEditingController();
    final price = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('New Product'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Product Name')),
            TextField(controller: weight, decoration: const InputDecoration(labelText: 'Weight')),
            TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Price')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              if (name.text.trim().isNotEmpty) {
                setState(() => products.add(Product(
                  name: name.text.trim(),
                  weight: weight.text.trim().isEmpty ? '1 Unit' : weight.text.trim(),
                  price: double.tryParse(price.text.trim()) ?? 0,
                )));
              }
              Navigator.pop(context);
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }
}
