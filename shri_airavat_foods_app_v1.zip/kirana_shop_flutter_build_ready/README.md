# Kirana Shop Flutter MVP

A simple starter MVP for a Kirana/grocery shop.

## Included
- Customer home/catalog
- Categories
- Product list with sample data
- Cart
- Checkout with Cash on Delivery
- Order history demo
- Admin dashboard
- Product/stock summary
- Sales summary demo

## Run
1. Install Flutter.
2. Run `flutter pub get`.
3. Run `flutter run`.

This MVP uses local in-memory data. For production, connect Firebase (Auth, Firestore, Storage, Cloud Messaging) and a payment gateway.
